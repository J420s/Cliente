

function open_new_window(){
    var myWindow;
    myWindow = window.open("", "myWindow", "width=200,height=100");     
    myWindow.document.write("<HTML><HEAD><TITLE>"+"Sin Título</TITLE></HEAD>\n");
    myWindow.document.write("<BODY>\n");        
    myWindow.document.write("<input type='button' value='Cerrar' onClick='window.close();'>\n");    
    myWindow.document.write("</BODY></HTML>\n");
}