
function get_IVA(price){
    if(isNaN(price)){alert("ERROR: No se reconoce el texto introducido")}
    var iva = price * 0.21;
    var total = price + iva;
    var result = [iva,total];
    return result;
}
result = get_IVA(parseInt(prompt("Introduzca precio:")));

alert("IVA: "+result[0]+"\n"+"Total: "+result[1].toFixed(2))