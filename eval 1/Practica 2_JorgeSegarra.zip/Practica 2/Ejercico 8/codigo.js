var url = location.href;
var path = location.pathname;
var pr = location.protocol_;
document.write("Su URL es: "+url+"<br> El Pathname es: "+path+"<br> El protocolo es: "+pr+"<br>");
function goTo(){
    window.location.href = 'https://www.google.com';
}