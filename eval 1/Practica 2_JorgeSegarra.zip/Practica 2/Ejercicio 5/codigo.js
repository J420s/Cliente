months = ["Enero","Febrero","Marzo","Abril",
        "Mayo","Junio","Julio","Agosto","Septiembre", 
        "Octubre","Noviembre","Diciembre"];

days = ["Lunes","Martes","Miercoles","Jueves",
        "Viernes","Sabado","Domingo"];

var f = new Date();

nday = f.getDay();
mday = f.getDate();
m = f.getMonth();
a = f.getFullYear();

function showDate(){
    alert(days[nday-1]+", "+mday+" de "+months[m]+" de "+a);
}