/* Identificamos mediante userAgent la cadena
 correspondiente a cada version de Internet Explorer */
var st = window.navigator.userAgent; 
var ie = st.indexOf("MSIE "); //IE version 10 o anterior
var ie11 = st.indexOf('Trident/'); //IE version 11
var ie12 = st.indexOf('Edge/'); //IE version 12

var r = confirm("Redimensionar a 500x500?"); 

//Damos al usuario la opcion de redimensionar
if(r){
    //Comprobamos si es IE y redimensionamos en tal caso
    if (ie > 0 || ie11 > 0 || ie12 > 0){
        window.resizeTo(500,500);
    }
    //En caso contrario informamos
    else{alert("Opcion no permitida con este navegador.")}
    
}




