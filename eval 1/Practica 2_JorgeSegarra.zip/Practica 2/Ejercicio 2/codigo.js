
  var mes = prompt("Dime un mes:").toUpperCase();
  
  switch(mes){
    case "DICIEMBRE": case "ENERO": case "FEBRERO":
      alert("invierno");  break;
    case "MARZO": case "ABRIL": case "MAYO":
      alert("primavera"); break;
    case "JUNIO": case "JULIO": case "AGOSTO":
      alert("verano");  break;
    case "SEPTIEMBRE": case "OCTUBRE": case "NOVIEMBRE":
      alert("otoño");   break;
    default:  
      alert("Introduzca un mes correcto");  break;
  }