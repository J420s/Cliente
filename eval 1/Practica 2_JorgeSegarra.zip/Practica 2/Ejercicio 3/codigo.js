

  document.write("<h1>Bienvenido a mi página</h1>");
  document.write("Tu navegador es: "+navigator.userAgent +"<br> Tu plataforma es: "+navigator.platform);
  var w = confirm("Desea continuar?");
  if (w){alert("Continuamos..")}
  