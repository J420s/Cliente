
var f = new Date();
h = f.getHours();
m = f.getMinutes();
st = "";
if(h > 7 && h < 14){st = "Buenos dias";}
if(h > 13 && h < 20){st = "Buenas tardes";}
if(h > 19 || h < 8){st = "Buenas noches";}
if(h<10){h="0"+h;}
if(m<10){m="0"+m;}


function showTime(){
    alert(st+", son las "+h+":"+m+" horas");
}