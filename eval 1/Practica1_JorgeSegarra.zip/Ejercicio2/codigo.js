
  var list = [7,8,2,9,10];
  var total = 0;
  for (n in list){
    if(list[n]>8){total+=list[n];}
  }
  alert(total);