
  var mes = prompt("Dime un mes:").toUpperCase();
  var inv = ["DICIEMBRE","ENERO","FEBRERO"];
  var prim = ["MARZO","ABRIL","MAYO"];
  var ver = ["JUNIO","JULIO","AGOSTO"];
  var oto = ["SEPTIEMBRE","OCTUBRE","NOVIEMBRE"];
  
  for(m in inv){
    if(mes==inv[m]){
      alert("invierno")
    }
  }
  for(m in prim){
    if(mes==prim[m]){
      alert("primavera")
    }
  }
  for(m in ver){
    if(mes==ver[m]){
      alert("verano")
    }
  }
  for(m in oto){
    if(mes==oto[m]){
      alert("otoño")
    }
  }