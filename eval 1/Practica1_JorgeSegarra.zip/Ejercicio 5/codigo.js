var p = parseInt(prompt("Introduzca precio:"));
var iva = p * 0.21;
var total = p + iva;
alert("IVA: "+iva+"\n"+"Total: "+total.toFixed(2))
