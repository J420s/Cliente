var chain = prompt("Introduce un texto: ");
var achain = chain.split(" ");

document.write("<p><b>Longitud:</b>"+chain.length+"</p>");
document.write("<p><b>Mayusculas:</b>"+chain.toUpperCase()+"</p>");
document.write("<p><b>Minusculas:</b>"+chain.toLowerCase()+"</p>");
document.write("<p><b>Split:</b></p>")
for(f in achain){
    document.write("<p>"+achain[f]+"<p>");
}

document.write("<p><b>Reverse:</b></p>")

var rchain = achain.reverse(); 

for (f in rchain){
    document.write("<p>"+rchain[f]+"<p>");
}

