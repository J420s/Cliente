
  
  var total = 0;
  list = [];
  for (i=0;i<5;i++){
    var n = prompt("Introduzca un numero:");
    total += parseInt(n);
    if(n>100){
      list.push(n);
    }
  }
  alert(total);
  if(list && list.lentgth){alert(list)}
  else{
    alert("No hay numeros mayores de 100")
  }