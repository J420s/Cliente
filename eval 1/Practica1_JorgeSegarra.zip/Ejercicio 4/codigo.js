
  n = prompt("Introduzca un numero:");
  if(n%2==0){alert("Par")}
  else{alert("Impar")}