input = window.prompt("Introduzca un número del 1 al 10:");
random = Math.floor(Math.random()*11);
if(input == random){
    alert("Felicidades! Has acertado.");
}
else{
    alert("Fallido!");
}