function sumar(){
    let current = parseInt(document.forms["myform"]["number"].value);
    document.forms["myform"]["number"].value = current + 10;
}

function restart(){
    document.forms["myform"]["number"].value = 0;
}