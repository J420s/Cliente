op = prompt("Introduce tu operación! \nIntroduce 'exit' para salir.");

while(op!="exit"){
    if(checkPrompt(op)){
        alert(eval(op));
    }
    else{alert("Introduzca una operación válida!")}
    
    function checkPrompt(p){
        var ops = ['+','-','*','/'];
        for (const c of p) {
            if(isNaN(c) && ops.includes(c)==false){return false;}
        }
        return true;
    }
    
    location.reload();
}



