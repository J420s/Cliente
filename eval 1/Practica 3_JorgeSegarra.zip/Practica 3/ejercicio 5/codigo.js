function myFunc(){
    document.write("<h1>Bienvenido!!!</h1>");
setInterval(window.open(),3000);

}


