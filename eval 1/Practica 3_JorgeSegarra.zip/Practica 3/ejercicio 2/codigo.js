function getDNI() {
    
    var dni = document.forms["DNIForm"]["dni"].value.trim();
    
    if(checkInput(dni)){document.getElementById("myForm").submit();}
    else{alert("Introduzca un formato correcto");}
}

function checkInput(input){
    var l = 0;
    var cont = 0;
    for(var n of input){
        if(isNaN(n)&&n.match(/[a-z]/i)){l++;}
        cont++;
    }
    if(l==1&&cont==9){return true;}
    else{return false;}
	}