function get_div(id){
    return document.getElementById(id);
}

function create_Par(text){
    let new_p = document.createElement('p');
    let new_text = document.createTextNode(text);
    new_p.appendChild(new_text);
    return new_p;
}

function add_par(){
    let new_p = create_Par('Párrafo añadido');
    get_div('1D').appendChild(new_p);
}

function insert_par(){
    let new_p = create_Par('Párrafo insertado');
    get_div('1D').insertBefore(new_p,get_div('1D').children[1]);
}

function replace_par(){
    let new_P = create_Par('Párrafo reemplazado');
    get_div('1D').replaceChild(new_P,get_div('1D').children[1]);
}

function delete_par(){
    get_div('1D').removeChild(get_div('1D').children[1]);
}

function clone_div(){
    let clone = get_div('1D').cloneNode(true);
    document.body.appendChild(clone);
}