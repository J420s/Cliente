
function set_div_color(color){
    if(color=='default'){
        let dColor = document.body.style.backgroundColor;
        document.getElementsByTagName("div")[0].style.backgroundColor = dColor;
    }
    else {
        document.getElementsByTagName("div")[0].style.backgroundColor = color;
    }
}
    
