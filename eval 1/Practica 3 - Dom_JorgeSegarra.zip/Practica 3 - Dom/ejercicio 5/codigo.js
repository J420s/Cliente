
window.onload = function(){
    let new_div = document.createElement('div');
    document.body.appendChild(new_div);
    new_div.setAttribute("name","box");
}