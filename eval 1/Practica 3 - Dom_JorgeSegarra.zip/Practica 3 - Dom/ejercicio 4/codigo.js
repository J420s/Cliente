
function get_img_number(){
    let imgNumber = document.getElementsByTagName("img").length;
    alert("En esta página hay "+imgNumber+" imágenes");
}

function get_link_number(){
    let linkNumber = document.getElementsByTagName("a").length;
    alert("En esta página hay "+linkNumber+" enlaces");
}