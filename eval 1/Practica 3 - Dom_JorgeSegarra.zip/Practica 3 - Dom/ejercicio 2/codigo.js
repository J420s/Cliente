function get_ul(id){
    return document.getElementById(id);
}

function create_li(text){
    let new_li = document.createElement('LI');
    let new_text = document.createTextNode(text);
    new_li.appendChild(new_text);
    return new_li;
}

function add_to_list(texto){
    let new_li = create_li(texto);
    get_ul('listaelemen').appendChild(new_li);
}

function insert_to_list(texto){
    let new_li = create_li(texto);
    get_ul('listaelemen').insertBefore(new_li,get_ul('listaelemen').children[1]);
}

function replace_in_list(texto){
    let new_li = create_li(texto);
    get_ul('listaelemen').replaceChild(new_li,get_ul('listaelemen').children[1]);
}

function delete_li(){
    get_ul('listaelemen').removeChild(get_ul('listaelemen').children[1]);
}

function clone_ul(){
    let clone = get_ul('listaelemen').cloneNode(true);
    document.body.appendChild(clone);
}

function add_sublist_dom(){
    let new_ul = document.createElement('UL');
    let new_li = create_li('tigre');
    new_ul.appendChild(new_li);
    get_ul('listaelemen').children[0].appendChild(new_ul);
}

function add_sublist_inner(){
    get_ul('listaelemen').children[0].innerHTML += "<ul><li>leopardo</li></ul>";
   
}