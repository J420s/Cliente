window.onload = function() {

    //Script 1
    document.getElementById('picture').src = welcome()

    //Script 2
    setTimeout(() => { popup() }, 5000);

    //Script 3
    let arrow = document.getElementById('arrow');
    addEventListener ? arrow.addEventListener("click", scrollDown) : arrow.attachEvent("onclick", scrollDown)

    //Script 4
    const images = Array.from(document.getElementsByClassName("card-img-top"))
    for (const image of images) {
        addEventListener ? image.addEventListener("click", preview) : image.attachEvent("onclick", preview)
    }

}

//Función que devuelve la ruta a una imagen dependiendo de la hora del navegador. 
function welcome() {
    var time = new Date()
    return time.getHours() > 8 && time.getHours() < 20 ? "media/img/cuadros/dessertArtist.jpg" : "media/img/cuadros/moonlightVan.jpg"
}


//Función que lanza un modal de bootstrap y añade un evento al botón "close" para cerrarlo al hacer click
function popup() {
    let modal = document.getElementById('myModal')
    modal.style.display = "block"
    modal.classList.add("show")
    let close = document.getElementById('close-modal')
    if (addEventListener) {
        close.addEventListener("click", function() {
            modal.style.display = "none"
            modal.classList.remove("show")
        })
    } else {
        close.attachEvent("onclick", function() {
            modal.style.display = "none"
            modal.classList.remove("show")
        })
    }
}

/**Función que, al hacer click sobre la flecha animada, revela una nueva sección de la página 
 * y hace scroll hacia ella suavemente**/
function scrollDown(e) {
    e.preventDefault();
    document.getElementById('galleryRow').classList.remove("hidden")
    scroller(document.getElementById('gallery'))
}

/**Función que, al hacer click sobre una de las imágenes de la nueva sección,
 * intercambia dicha imágen en la portada,
 * hace scroll hacia la portada suavemente
 * y esconde esta sección nuevamente al trascurrir un segundo.
 */
function preview(e) {
    e.preventDefault();
    document.getElementById('picture').src = this.src
    scroller(document.getElementById('picture'))
    setTimeout(() => { document.getElementById('galleryRow').classList.add("hidden") }, 1000);

}

//Función para hacer scroll suave hacia un elemento pasando este por parámetro
function scroller(elem) {
    scroll({
        top: elem.offsetTop,
        behavior: "smooth"
    });
}