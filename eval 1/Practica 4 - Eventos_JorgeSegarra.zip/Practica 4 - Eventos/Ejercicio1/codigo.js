
function inc_size(element){
    element.style.fontSize = "16pt";
}

function dec_size(element){
    element.style.fontSize = "12pt";
}