$(document).ready(() => {
    $("p").hover(function() {
        $(this).toggleClass("bigger")
    });
})