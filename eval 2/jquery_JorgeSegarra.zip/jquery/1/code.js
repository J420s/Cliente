$(document).ready(function() {
    $('div').css("color", "green")
    alert($('div').length)
})